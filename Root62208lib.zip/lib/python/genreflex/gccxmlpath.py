gccxmlpath = 'c:/Users/bellenot/bin/gccxml/bin'
