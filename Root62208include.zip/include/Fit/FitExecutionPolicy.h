#ifndef ROOT_Fit_FitExecutionPolicy
#define ROOT_Fit_FitExecutionPolicy
namespace ROOT{
   namespace Fit{
      enum class ExecutionPolicy { kSerial, kMultithread, kMultiprocess };
    }
}

#endif
