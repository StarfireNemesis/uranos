/* @(#)root/base:$Id$ */
/* Author: Fons Rademakers   16/11/2006 */

#ifndef ROOT_config
#define ROOT_config

/*
 * Obsolete, use RConfigure.h instead.
 * Should only be used in ROOT implementation files as the name is too trivial.
 */

#ifndef ROOT_RConfigure
#include "RConfigure.h"
#endif

#warning config.h is deprecated, replace by RConfigure.h.

#endif
