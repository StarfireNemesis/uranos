#ifndef ROOT_RGITCOMMIT_H
#define ROOT_RGITCOMMIT_H
  #define ROOT_GIT_BRANCH ""
  #define ROOT_GIT_COMMIT ""
#endif