// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_BoostY
#define ROOT_Math_BoostY


#include "Math/GenVector/BoostY.h"


#endif
