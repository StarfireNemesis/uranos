// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_EulerAngles
#define ROOT_Math_EulerAngles


#include "Math/GenVector/EulerAngles.h"


#endif
