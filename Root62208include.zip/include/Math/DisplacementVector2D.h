// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_DisplacementVector2D
#define ROOT_Math_DisplacementVector2D


#include "Math/GenVector/DisplacementVector2D.h"


#endif
