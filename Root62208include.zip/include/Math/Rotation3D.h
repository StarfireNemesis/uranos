// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_Rotation3D
#define ROOT_Math_Rotation3D


#include "Math/GenVector/Rotation3D.h"


#endif
