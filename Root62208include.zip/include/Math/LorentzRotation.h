// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_LorentzRotation
#define ROOT_Math_LorentzRotation


#include "Math/GenVector/LorentzRotation.h"


#endif
