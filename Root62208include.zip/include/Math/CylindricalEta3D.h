// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_CylindricalEta3D
#define ROOT_Math_CylindricalEta3D


#include "Math/GenVector/CylindricalEta3D.h"


#endif
