// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_AxisAngle
#define ROOT_Math_AxisAngle


#include "Math/GenVector/AxisAngle.h"


#endif
