// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_PtEtaPhiE4D
#define ROOT_Math_PtEtaPhiE4D


#include "Math/GenVector/PtEtaPhiE4D.h"


#endif
