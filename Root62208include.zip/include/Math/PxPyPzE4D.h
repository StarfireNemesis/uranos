// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_PxPyPzE4D
#define ROOT_Math_PxPyPzE4D


#include "Math/GenVector/PxPyPzE4D.h"


#endif
