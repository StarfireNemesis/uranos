// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_Translation3D
#define ROOT_Math_Translation3D


#include "Math/GenVector/Translation3D.h"


#endif
