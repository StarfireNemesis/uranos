// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_PtEtaPhiM4D
#define ROOT_Math_PtEtaPhiM4D


#include "Math/GenVector/PtEtaPhiM4D.h"


#endif
