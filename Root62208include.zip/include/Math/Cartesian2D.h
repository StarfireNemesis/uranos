// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_Cartesian2D
#define ROOT_Math_Cartesian2D


#include "Math/GenVector/Cartesian2D.h"


#endif
