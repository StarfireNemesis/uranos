// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_Transform3D
#define ROOT_Math_Transform3D


#include "Math/GenVector/Transform3D.h"


#endif
