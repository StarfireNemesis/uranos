// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_PositionVector2D
#define ROOT_Math_PositionVector2D


#include "Math/GenVector/PositionVector2D.h"


#endif
