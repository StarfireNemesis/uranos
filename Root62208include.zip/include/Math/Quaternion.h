// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_Quaternion
#define ROOT_Math_Quaternion


#include "Math/GenVector/Quaternion.h"


#endif
