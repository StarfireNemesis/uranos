// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_RotationX
#define ROOT_Math_RotationX


#include "Math/GenVector/RotationX.h"


#endif
