// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_PxPyPzM4D
#define ROOT_Math_PxPyPzM4D


#include "Math/GenVector/PxPyPzM4D.h"


#endif
