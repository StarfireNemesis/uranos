// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_Polar2D
#define ROOT_Math_Polar2D


#include "Math/GenVector/Polar2D.h"


#endif
